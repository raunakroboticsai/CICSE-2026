// ======================================================
// Config.h  -  MISSION 2  "TEACH & REPLAY"
// Hardware + START values. Everything you TEACH is saved in EEPROM by the
// serial commands - you do NOT need to edit this file again.
// ======================================================
#ifndef M2_CONFIG_H
#define M2_CONFIG_H

#define BUILD_NAME "MISSION 2 - TEACH & REPLAY v9 (kits per servo)"
#define SAFE_MODE 1

#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>
#include <Adafruit_PWMServoDriver.h>

// ---------------- DRIVE MOTORS (tested) ----------------
#define M1_PWM 2
#define M1_IN1 31
#define M1_IN2 30
#define M2_PWM 3
#define M2_IN1 32
#define M2_IN2 33
#define M3_PWM 4
#define M3_IN1 35
#define M3_IN2 34
#define M4_PWM 5
#define M4_IN1 36
#define M4_IN2 37
#define M4_REVERSED 1

#define SPEED 140
#define SLOW_SPEED 85
#define COUNTS_PER_MM 20.3718

// start values - change with the serial commands  ffwd / fstrafe
#define DEF_FORWARD_FACTOR  1.100
#define DEF_STRAFE_FACTOR   1.414
#define DIAGONAL_FACTOR     1.750

#define ROTATION_MIRRORED 1
#define TURN_90_WHEEL_MM 380
#define ENCODER_TOLERANT  0

// ---------------- MPU6050 GYRO (tested) ----------------
#define USE_MPU           1
#define MPU_ADDR          0x68
#define MPU_REQUIRED      1
#define GYRO_AXIS         2
#define GYRO_SIGN        -1
#define MPU_CAL_SAMPLES   400
#define HEADING_KP        0.040
#define HEADING_KD        0.004
#define HEADING_MAX       0.25
#define ASSIST_KP_PWM     14.0
#define ASSIST_KD_PWM     2.5
#define ASSIST_KI_PWM     12.0
#define ASSIST_I_MAX      35
#define ASSIST_MAX_PWM    60
#define ASSIST_SIGN        1
#define MPU_GLITCH_DPS    300.0
#define HEADING_FIX_ENABLE   1
#define HEADING_FIX_TOL_DEG  0.8
#define STRAFE_RIGHT_FWD_TRIM_PWM   0
#define STRAFE_LEFT_FWD_TRIM_PWM    0
#define SYNC_KP_GYRO      0.15
#define TURN_TOL_DEG      0.4
#define TURN_FINE_PWM     110
#define TURN_FINE_MS_PER_DEG 30

// ---------------- SPEED CONTROL (only if SAFE_MODE 0) ----------------
#define SPEED_CONTROL     (SAFE_MODE ? 0 : 1)
#define REF_CPS_DEFAULT   5000
#define V_MAX_FRAC        0.85
#define V_SLOW_FRAC       0.30
#define V_CREEP_FRAC      0.12
#define A_ACC_FRAC        2.5
#define A_DEC_FRAC        2.0
#define CTRL_MS           20
#define SPEED_FILTER      0.4
#define SPEED_GAIN        0.25
#define SYNC_KP           3.0
#define START_PWM         90
#define BRAKE_MS         (SAFE_MODE ? 0 : 60)
#define TRIM_ENABLE       (SAFE_MODE ? 0 : 1)
#define TRIM_TOL_MM     2.0
#define TRIM_MAX_MS    1500

// ---------------- ARM (PCA9685 0x40) ----------------
#define PCA9685_ADDR  0x40
#define BASE_SERVO    0
#define BOTTOM_SERVO  1
#define TOP_SERVO     2
#define BASE_MIN    100
#define BASE_MAX    560
#define BOTTOM_MIN  150
#define BOTTOM_MAX  510
#define TOP_MIN     270
#define TOP_MAX     530

// START poses (teach with:  pose idle / pose init / pose scan / pose scanl)
#define IDLE_BASE      331
#define IDLE_BOTTOM    330
#define IDLE_TOP       530
#define INITIAL_BASE   320
#define INITIAL_BOTTOM 365
#define INITIAL_TOP    480
#define SCAN_BASE      195       // arm to the RIGHT, camera looks down
#define SCAN_BOTTOM    300
#define SCAN_TOP       320
#define SCAN_LEFT_BASE 445       // arm to the LEFT
#define PICK_BOTTOM    441       // first guess of the pick pose (each slot is taught)
#define PICK_TOP       270
#define PLACE_BASE     335       // first guess of the place pose (each zone is taught)
#define PLACE_BOTTOM   470
#define PLACE_TOP      270

#define HOVER_FRACTION   0.30    // arm first goes to a point 30% back towards the scan pose
#define ARM_MOVE_MS      1200
#define ARM_DOWN_MS      1500
#define PICK_DWELL_MS    2500    // nozzle stays ON the patient (suction builds up)
#define PICK_LIFT_MS     1500    // slow lift
#define PLACE_DWELL_MS    800

// ---------------- SUCTION (pump switch board, servo pulse) ----------------
#define SUCTION_CHANNEL       7       // <<< YOUR PUMP CHANNEL
#define SUCTION_PULSE_ON_US   2000
#define SUCTION_PULSE_OFF_US  1000

// ---------------- KIT SERVOS (SG90, kick) ----------------
// PCA9685 channel of each kit servo
#define KIT_CH_HOSPITAL   14
#define KIT_CH_PCC1       13
#define KIT_CH_PCC2       15
// START angles (degrees). Change them on the robot - no upload needed:
//    kitset h 90 60      (zone  REST  KICK)   -> saved in EEPROM
//    kitdeg h 75         (move that servo to 75 now, to find the angle)
//    kitreset            (back to the values below)
#define KIT_HOSP_REST     90
#define KIT_HOSP_KICK     60
#define KIT_PCC1_REST     90
#define KIT_PCC1_KICK     65
#define KIT_PCC2_REST    100
#define KIT_PCC2_KICK     75
#define KIT_KICK_MS      600
#define KIT_RETURN_MS    400
#define KIT_KICK_TIMES     1
#define KIT_SERVO_MIN    110
#define KIT_SERVO_MAX    510

// ---------------- CAMERA (Grove Vision AI V2, 240 x 240) ----------------
#define CLASS_RED        0
#define CLASS_YELLOW     1
#define CLASS_GREEN      2       // class 3 = "sample" (ignored)
#define MIN_SCORE        50
#define CONFIRM_FRAMES   3
#define SCAN_TIMEOUT_MS  3000
#define IMAGE_CENTER_X   120
#define IMAGE_CENTER_Y   120
#define LOOK_MS          900
#define SETTLE_MS        350

// ---- box centre from x / y / w / h (v6) ----
#define IMAGE_W          240
#define IMAGE_H          240
#define BOX_XY_IS_CENTER   1     // 1 = camera sends the box CENTRE as x,y (Grove Vision AI V2 / SSCMA)
                                 // 0 = camera sends the TOP-LEFT corner -> centre = x + w/2, y + h/2
                                 //     (check with "live": see the README, after changing -> teach again)
#define EDGE_MARGIN_PX     2     // box touching the picture edge = patient cut off -> centre wrong -> not used for aiming
#define ALIGN_TO_IMAGE_CENTER 0  // 0 = aim at the pixel recorded in "teach" (recommended)
                                 // 1 = aim at the picture middle (only if the camera looks straight down the nozzle)
#define ALIGN_FRAMES       5     // precise look: middle value (median) of this many pictures
#define ALIGN_MIN_FRAMES   3
#define ALIGN_LOOK_MS   2000

// fine correction before each pick: arm base (one direction) + wheels (the other direction)
#define FINE_ENABLE        1
#define FINE_TOL_PX        3
#define FINE_ROUNDS        5
#define FINE_MAX_UNITS    15
#define FINE_GAIN        0.9
#define CAL_BASE_UNITS    10
#define FINE_WHEELS        1     // 1 = also strafe the robot a few mm (needs "teach N" again once)
#define CAL_STRAFE_MM     10     // teach: strafe this much to learn how the picture moves
#define FINE_WHEEL_MIN_MM 1.5    // smaller wheel corrections are skipped
#define FINE_MAX_MM       12     // never correct more than this with the wheels

// pick check
#define PICK_MAX_TRIES     8     // search pattern around the aimed point (max 9 = full 3 x 3)
#define PICK_STEP_MM       3     // distance between the search points (mm)
#define PICK_STEP_BASE     2     // arm-base units per step if the slot has no wheel-cal
#define PICK_SHIFT_WHEELS  1     // 1 = search points also left/right with the wheels, 0 = arm base only
#define PICK_RETRY_PRESS   2     // retries press the nozzle this much lower (bottom servo units)
// v8: "PICK OK" only with PROOF: the camera must answer on VERIFY_CLEAR_FRAMES pictures
// and NONE of them may show a patient near the pick spot. One sighting = NOT picked.
#define VERIFY_MS          3000  // max time for the check
#define VERIFY_CLEAR_FRAMES   4  // answered pictures needed to say "gone"
#define VERIFY_MIN_SCORE     30  // lower than MIN_SCORE: a tilted / pushed patient still counts
#define VERIFY_RADIUS_PX     40  // search circle around the pick spot (at least this)
#define VERIFY_RADIUS_SIZE  1.2  // ... or 1.2 x the patient size (w / h) - catches a pushed patient
#define VERIFY_SETTLE_MS    500  // arm still before the check (sharp picture)
#define VERIFY_FRAMES         2  // (old check, not used any more)

// ---------------- MAP  (0,0) = H CENTER, +X = forward (hospital), +Y = left ----------------
#define START_DELAY_MS   5000UL     // wait after START (gyro calibrates in this time)
// START PATH (robot stands in the start zone facing the CENTRE-NODE side, NOT the hospital):
//   strafe RIGHT leg1 -> FORWARD leg2 -> strafe RIGHT leg3 -> TURN RIGHT 90 -> faces hospital on H CENTER
#define DEF_LEG1   236.0      // start: strafe RIGHT out of the start zone   command: leg1
#define DEF_LEG2   432.0      // start: FORWARD up to the H line              command: leg2
#define DEF_LEG3   215.0      // start: strafe RIGHT onto H CENTER            command: leg3
#define START_TURN_RIGHT 1    // 1 = turn right 90 deg on H CENTER (face hospital), 0 = no turn
#define RUN_KITS         1    // 1 = kits are kicked before the patients, 0 = patients only

#define HOSP_X      255.0
#define HOSP_Y        0.0
#define PCC1_X      255.0
#define PCC1_Y      320.5
#define PCC2_X      255.0
#define PCC2_Y     -301.5
#define RECOV_X    -340.0     // back ~340 mm from H CENTER (yellow path)
#define RECOV_Y     -50.0

// patient dots (CAD). Rows: X = +100 (hospital side) and -100 (start side)
#define ROW_HOSP_X        100.0
#define ROW_START_X      -100.0
#define RIGHT_Y1  -221.5
#define RIGHT_Y2  -321.5
#define RIGHT_Y3  -421.5
#define LEFT_Y1    259.5
#define LEFT_Y2    359.5
#define LEFT_Y3    459.5
#define PICK_REACH_MM   241.0    // robot stops this far beside the dot (arm reaches sideways)

#define NAV_TOL_MM        2.0
#define DROP_SPREAD_MM   45.0

// ---------------- BUTTONS / I2C ----------------
#define START_BUTTON_PIN 22
#define STOP_BUTTON_PIN  29
#define I2C_SDA_PIN      20
#define I2C_SCL_PIN      21

#define SZ(d) ((d) > 150 ? 40 : 10)

// ======================================================
// TYPES
// ======================================================
enum MoveType { DIAGONAL_FRONT_RIGHT, ROTATE_RIGHT, STRAFE_RIGHT, BACKWARD, STRAFE_LEFT, FORWARD, ROTATE_LEFT };
enum PatientColor { COL_NONE = 0, COL_RED, COL_GREEN, COL_YELLOW };
enum Zone { ZONE_HOSPITAL = 0, ZONE_PCC1, ZONE_PCC2, ZONE_RECOVERY, ZONE_COUNT };

struct Pose3 { int b, bo, t; };

#define MAX_BOXES 10
struct Box { int x, y, w, h, score, target; };

#define SLOT_COUNT 12
struct SlotData {            // one patient dot
  byte ok;                   // taught
  byte hasPix;               // camera pixel recorded
  float dx, dy;              // taught robot offset from the nominal stop (mm)
  Pose3 pick;                // arm pose with the nozzle ON the patient
  int px, py;                // where the camera sees this patient (scan pose)
};

struct ZoneData {            // one drop zone
  byte ok;
  float dx, dy;              // taught robot offset from the nominal zone point (mm)
  Pose3 place;               // arm pose to drop
};

#define KIT_COUNT   3          // [0] = HOSPITAL  [1] = PCC1  [2] = PCC2   (same order as Zone)
#define KIT_OK_MAGIC 0xA7

#define STORE_MAGIC 0xC5A7
struct Store {
  uint16_t magic;
  Pose3 idle, init, scan;
  int scanLeftBase;
  SlotData slot[SLOT_COUNT];
  ZoneData zone[ZONE_COUNT];
  float bx, by;              // camera: px per arm-base unit
  byte baseCal;
  float fwdF, strafeF;
  float leg1, leg2, leg3;
  byte kitsPCC;
  float backF;               // backward factor (command: fback)
  // v6: wheel fine correction, learned per slot by "teach N". New fields only AFTER this line.
  float sx[SLOT_COUNT], sy[SLOT_COUNT];   // camera: px per mm strafe LEFT
  byte strafeCal[SLOT_COUNT];
  // v9: kit servo angles (command: kitset). New fields only AFTER this line.
  byte kitRest[KIT_COUNT], kitKick[KIT_COUNT];
  byte kitOk;
};

// ======================================================
// SHARED
// ======================================================
extern Store st;
extern Adafruit_PWMServoDriver pwm;
extern bool missionAborted, suctionActive, stepMode, mpuOk, visionOk;
extern bool moveAllowStall, lastMoveHitWall, assistEnabled, assistLog;
extern byte stepCounter;
extern float armBase, armBottom, armTop;
extern Box boxes[MAX_BOXES];
extern int boxCount;
extern float refCps, yawDeg, yawRate, headingRef, moveYaw0;
extern uint8_t mpuAddress;
extern float assistSumAbs, assistMaxAbs;
extern unsigned int assistN, mpuFailTotal, mpuGlitchTotal;
extern PatientColor lastColor;
extern float navX, navY;
extern unsigned long missionT0;

// Mission22.ino
bool abortRequested();
bool stepWait();
bool mgate(const __FlashStringHelper *name);
bool mdrive(MoveType t, float mm, float slow);
bool readLine(char *buf, byte n, bool blocking);
void i2cScan();
void preflight();

// Movement.ino
void encodersBegin();
void readEnc(long r[4]);
void resetEncoders();
void motorRun(byte pwmPin, byte in1, byte in2, int speed);
void stopMotors();
void brakeMotors(unsigned int ms);
void settleWait(unsigned long ms);
float moveProgress(MoveType type);
void wheelDirs(MoveType type, int8_t d[4]);
bool moveFinish(MoveType type, float targetCounts);
bool encoderMoveOpen(float mm, float factor, MoveType type, float slowDistance);
bool encoderMoveClosed(float mm, float factor, MoveType type, float slowDistance);
void speedLoad();
void speedTest();
void wheelTest();
void runMovement(MoveType type, int spd);
void runMovementAssist(MoveType type, int spd);
bool fixHeading();
bool encoderMove(float mm, float factor, MoveType type, float slowDistance);
const char *moveName(MoveType type);
float moveFactor(MoveType type);
bool smallMove(MoveType type, float mm);
bool drive(MoveType type, float mm, float slowDistance);

// Mpu.ino
bool mpuBegin();
bool mpuCalibrate();
void mpuUpdate();
void mpuTest();

// Vision.ino
bool gv2Present();
int gv2Invoke();
bool isPatientClass(int t);
PatientColor classToColor(int t);
const char *colorName(PatientColor c);
void setAim(int x, int y);
bool lookForSample(int &x, int &y, unsigned long timeoutMs);
bool sampleNear(int tx, int ty, int radius, unsigned long timeoutMs, int &ox, int &oy);
int pickCheck(int tx, int ty, int radius, int &ox, int &oy);
extern int lastBoxW, lastBoxH;
bool lookPrecise(int &x, int &y, int &w, int &h, unsigned long timeoutMs);
bool boxCut(const Box &b);
void cameraTest();

// Store.ino
void storeDefaults();
void kitDefaults();
void kitShow();
void storeLoad();
void storeSave();
void storeShow();
Pose3 slotDefaultPose(byte s);

// Arm.ino
void armApply();
bool armMoveTo(int b, int bo, int t, unsigned long ms);
bool armToPose(const Pose3 &p, unsigned long ms);
bool armToInitial();
bool armToIdle();
bool armScanAt(int base);
bool armLiftHere();
bool armOver(float b, float bo, float t);
bool armDown(float b, float bo, float t);
void setSuction(bool on);
bool waitMs(unsigned long ms);
void kitsHoldAll();
bool kitRelease(Zone z);
void kitMoveDeg(Zone z, int deg);
byte kitChannel(Zone z);

// Nav.ino
bool navRelX(float mm);
bool navRelY(float mm);
bool navGoTo(float x, float y, const __FlashStringHelper *name);
bool navReturnNode();
bool navStartToNode();
bool slotIsRight(byte s);
void slotStop(byte s, float &x, float &y);
bool navToSlot(byte s);
bool navToZone(Zone z, byte dropIndex);
const __FlashStringHelper *zoneName(Zone z);
Zone zoneFor(PatientColor c, bool rightSide);

// Teach.ino
bool teachSlot(byte s);
bool teachZone(Zone z);
bool teachPose(byte which);

// Mission.ino
void missionReset();
bool gyroStart(unsigned long waitTotalMs);
bool lookSlot(byte s, PatientColor &c);
bool pickSlot(byte s, PatientColor &c);
bool placeInZone(Zone z, byte k, byte n);
bool processSlot(byte s);
bool deliverKits();
bool runFromNode(bool kits);
bool runMission();
void lookAll();
bool zoneTour();
bool slotTour();
void printSummary();

#endif
