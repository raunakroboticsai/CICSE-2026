// ======================================================
// Nav.ino  -  MAP + DRIVING FROM / TO THE H CENTER (node)
//
// (0,0) = H CENTER. +X = forward (hospital), +Y = left (PCC1).
// Out: X first, then Y.   Back: Y first, then X (same path).
//
// SLOTS (the robot stops BESIDE the dot, the arm reaches sideways):
//   1 2 3  = RIGHT, hospital row (1 = nearest)     arm RIGHT
//   4 5 6  = RIGHT, start row    (4 = nearest)     arm RIGHT
//   7 8 9  = LEFT,  hospital row (7 = nearest)     arm LEFT
//  10 11 12= LEFT,  start row   (10 = nearest)     arm LEFT
// Each slot / zone adds its TAUGHT offset (teach N / tz ...).
// ======================================================
#include "Config.h"

float navX = 0, navY = 0;

bool navRelX(float mm) {
  if (fabs(mm) <= NAV_TOL_MM) return true;
  return mdrive(mm > 0 ? FORWARD : BACKWARD, fabs(mm), SZ(fabs(mm)));
}

bool navRelY(float mm) {
  if (fabs(mm) <= NAV_TOL_MM) return true;
  return mdrive(mm > 0 ? STRAFE_LEFT : STRAFE_RIGHT, fabs(mm), SZ(fabs(mm)));
}

bool navGoTo(float x, float y, const __FlashStringHelper *name) {
  Serial.print(F("NAV -> "));
  Serial.print(name);
  Serial.print(F(" ("));
  Serial.print(x, 0);
  Serial.print(F(", "));
  Serial.print(y, 0);
  Serial.println(F(")"));
  if (!navRelX(x - navX)) return false;
  navX = x;
  if (!navRelY(y - navY)) return false;
  navY = y;
  return true;
}

bool navReturnNode() {
  Serial.println(F("NAV -> H CENTER"));
  if (!navRelY(-navY)) return false;
  navY = 0;
  if (!navRelX(-navX)) return false;
  navX = 0;
  return true;
}

// start zone -> H CENTER   (legs: commands leg1 / leg2 / leg3)
// strafe RIGHT leg1 -> FORWARD leg2 -> strafe RIGHT leg3 -> TURN RIGHT 90 (now facing the hospital)
bool navStartToNode() {
  Serial.println(F("=== START ZONE -> H CENTER ==="));
  if (!mgate(F("1) strafe RIGHT out of the start zone"))) return false;
  if (st.leg1 > NAV_TOL_MM && !mdrive(STRAFE_RIGHT, st.leg1, SZ(st.leg1))) return false;
  if (!mgate(F("2) FORWARD"))) return false;
  if (st.leg2 > NAV_TOL_MM && !mdrive(FORWARD, st.leg2, SZ(st.leg2))) return false;
  if (!mgate(F("3) strafe RIGHT onto H CENTER"))) return false;
  if (st.leg3 > NAV_TOL_MM && !mdrive(STRAFE_RIGHT, st.leg3, SZ(st.leg3))) return false;
#if START_TURN_RIGHT
  if (!mgate(F("4) TURN RIGHT 90 - face the hospital"))) return false;
  if (!mdrive(ROTATE_RIGHT, TURN_90_WHEEL_MM, 60)) return false;
#endif
  navX = 0;
  navY = 0;
  Serial.println(F("AT H CENTER"));
  return true;
}

// ---- slots ----
static void slotNominal(byte s, float &x, float &y) {
  bool right = slotIsRight(s);
  byte i = s % 6;
  x = (i < 3) ? ROW_HOSP_X : ROW_START_X;
  byte k = i % 3;
  float dotY;
  if (right) dotY = (k == 0) ? RIGHT_Y1 : (k == 1) ? RIGHT_Y2 : RIGHT_Y3;
  else       dotY = (k == 0) ? LEFT_Y1  : (k == 1) ? LEFT_Y2  : LEFT_Y3;
  y = dotY + (right ? PICK_REACH_MM : -PICK_REACH_MM);
}

void slotStop(byte s, float &x, float &y) {
  slotNominal(s, x, y);
  if (st.slot[s].ok) { x += st.slot[s].dx; y += st.slot[s].dy; }
}

bool navToSlot(byte s) {
  float x, y;
  slotStop(s, x, y);
  Serial.print(F("SLOT "));
  Serial.println(s + 1);
  return navGoTo(x, y, F("patient slot"));
}

// ---- zones ----
const __FlashStringHelper *zoneName(Zone z) {
  switch (z) {
    case ZONE_HOSPITAL: return F("HOSPITAL");
    case ZONE_PCC1:     return F("PCC1");
    case ZONE_PCC2:     return F("PCC2");
    default:            return F("RECOVERY");
  }
}

// RED -> Hospital, YELLOW -> PCC of that side, GREEN -> Recovery
Zone zoneFor(PatientColor c, bool rightSide) {
  if (c == COL_RED)    return ZONE_HOSPITAL;
  if (c == COL_YELLOW) return rightSide ? ZONE_PCC2 : ZONE_PCC1;
  return ZONE_RECOVERY;
}

static void zoneNominal(Zone z, float &x, float &y) {
  switch (z) {
    case ZONE_HOSPITAL: x = HOSP_X;  y = HOSP_Y;  break;
    case ZONE_PCC1:     x = PCC1_X;  y = PCC1_Y;  break;
    case ZONE_PCC2:     x = PCC2_X;  y = PCC2_Y;  break;
    default:            x = RECOV_X; y = RECOV_Y; break;
  }
  if (st.zone[z].ok) { x += st.zone[z].dx; y += st.zone[z].dy; }
}

// dropIndex 0,1,2,3,4 -> 0, +s, -s, +2s, -2s  (patients do not land on each other)
bool navToZone(Zone z, byte dropIndex) {
  float x, y;
  zoneNominal(z, x, y);
  if (dropIndex > 0) {
    float k = (float)((dropIndex + 1) / 2);
    y += ((dropIndex % 2) ? 1.0 : -1.0) * k * DROP_SPREAD_MM;
  }
  return navGoTo(x, y, zoneName(z));
}
