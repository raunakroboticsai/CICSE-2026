// ======================================================
// Teach.ino  -  TEACH SLOTS, ZONES, ARM POSES (saved in EEPROM)
//
// JOG KEYS (type the letters and press Enter; "www" = 3 steps):
//   wheels:  w = forward   s = back   a = left   d = right     m = step 10 / 5 mm
//   arm:     j / l = base - / +
//            i / k = bottom + / -
//            u / o = top + / -                                 z = step 5 / 2 / 1
//   v = suction ON/OFF (test the grip)    c = camera look
//   y = SAVE          q = quit (not saved)
// ======================================================
#include "Config.h"

static float jogF = 0, jogS = 0;       // wheel jog (mm forward / mm left) since the teach started

static void jogStatus() {
  Serial.print(F("   ARM base="));
  Serial.print((int)armBase);
  Serial.print(F(" bottom="));
  Serial.print((int)armBottom);
  Serial.print(F(" top="));
  Serial.print((int)armTop);
  Serial.print(F("   | robot moved fwd="));
  Serial.print(jogF, 0);
  Serial.print(F(" left="));
  Serial.print(jogS, 0);
  Serial.println(F(" mm"));
}

static void jogHelp(bool wheels) {
  if (wheels) Serial.println(F("   WHEELS: w fwd  s back  a left  d right   m = step 10/5 mm"));
  Serial.println(F("   ARM:    j/l base -/+   i/k bottom +/-   u/o top +/-   z = step 5/2/1"));
  Serial.println(F("   v = suction ON/OFF   c = camera look   y = SAVE   q = quit"));
}

// wheel jog: lift the arm a little, move, put it back
static bool jogWheel(MoveType t, float mm) {
  int b = (int)armBase, bo = (int)armBottom, tp = (int)armTop;
  if (!armOver(b, bo, tp)) return false;
  if (!smallMove(t, mm)) return false;
  if (!fixHeading()) return false;
  if (t == FORWARD)      { jogF += mm; navX += mm; }
  if (t == BACKWARD)     { jogF -= mm; navX -= mm; }
  if (t == STRAFE_LEFT)  { jogS += mm; navY += mm; }
  if (t == STRAFE_RIGHT) { jogS -= mm; navY -= mm; }
  return armMoveTo(b, bo, tp, 600);
}

static void cameraLookHere() {
  int b = (int)armBase, bo = (int)armBottom, tp = (int)armTop;
  if (!armOver(b, bo, tp) || !armLiftHere()) return;
  waitMs(SETTLE_MS);
  int x, y;
  setAim(IMAGE_CENTER_X, IMAGE_CENTER_Y);
  if (lookForSample(x, y, LOOK_MS)) {
    Serial.print(F("   camera: "));
    Serial.print(colorName(lastColor));
    Serial.print(F(" at x="));
    Serial.print(x);
    Serial.print(F(" y="));
    Serial.println(y);
  } else {
    Serial.println(F("   camera: no patient seen"));
  }
  armOver(b, bo, tp);
  armMoveTo(b, bo, tp, 600);
}

// returns 1 = saved, 0 = quit, -1 = stopped
static int jogLoop(bool wheels) {
  int armStep = 5;
  float wStep = 10;
  char line[40];
  jogHelp(wheels);
  jogStatus();

  while (true) {
    if (!readLine(line, sizeof(line), true)) return -1;
    for (byte i = 0; line[i]; i++) {
      char c = line[i];
      if (c >= 'A' && c <= 'Z') c += 32;
      float nb = armBase, nbo = armBottom, nt = armTop;
      bool armMove = false;

      switch (c) {
        case 'y': return 1;
        case 'q': case 'x': Serial.println(F("   quit - NOT saved")); return 0;
        case 'h': case '?': jogHelp(wheels); break;
        case 'z': armStep = (armStep == 5) ? 2 : (armStep == 2) ? 1 : 5;
                  Serial.print(F("   arm step ")); Serial.println(armStep); break;
        case 'm': wStep = (wStep == 10) ? 5 : 10;
                  Serial.print(F("   wheel step ")); Serial.print(wStep, 0); Serial.println(F(" mm")); break;
        case 'j': nb -= armStep; armMove = true; break;
        case 'l': nb += armStep; armMove = true; break;
        case 'i': nbo += armStep; armMove = true; break;
        case 'k': nbo -= armStep; armMove = true; break;
        case 'u': nt += armStep; armMove = true; break;
        case 'o': nt -= armStep; armMove = true; break;
        case 'v': setSuction(!suctionActive); break;
        case 'c': cameraLookHere(); break;
        case 'w': if (wheels && !jogWheel(FORWARD, wStep)) return -1; break;
        case 's': if (wheels && !jogWheel(BACKWARD, wStep)) return -1; break;
        case 'a': if (wheels && !jogWheel(STRAFE_LEFT, wStep)) return -1; break;
        case 'd': if (wheels && !jogWheel(STRAFE_RIGHT, wStep)) return -1; break;
        default: break;
      }
      if (armMove && !armMoveTo((int)nb, (int)nbo, (int)nt, 200)) return -1;
      missionAborted = false;
    }
    jogStatus();
  }
}

static bool teachStart() {
  missionReset();
  setSuction(false);
  Serial.println(F("Robot must stand on H CENTER, facing the hospital. Gyro calibrating..."));
  return gyroStart(0);
}

// ---------------- TEACH ONE PATIENT SLOT ----------------
bool teachSlot(byte s) {
  Serial.println();
  Serial.print(F("=== TEACH SLOT "));
  Serial.print(s + 1);
  Serial.println(slotIsRight(s) ? F(" (RIGHT) ===") : F(" (LEFT) ==="));
  Serial.println(F("Put a patient on this dot first."));
  if (!teachStart()) return false;

  if (!armToInitial()) return false;
  if (!navToSlot(s)) return false;

  Pose3 p = st.slot[s].ok ? st.slot[s].pick : slotDefaultPose(s);
  if (!armScanAt(p.b)) return false;
  waitMs(SETTLE_MS);
  int x, y;
  setAim(IMAGE_CENTER_X, IMAGE_CENTER_Y);
  if (lookForSample(x, y, LOOK_MS)) {
    Serial.print(F("Camera sees "));
    Serial.print(colorName(lastColor));
    Serial.print(F(" at x="));
    Serial.print(x);
    Serial.print(F(" y="));
    Serial.println(y);
  } else {
    Serial.println(F("Camera does not see the patient yet - move closer with the wheels / arm."));
  }

  if (!armOver(p.b, p.bo, p.t)) return false;
  if (!armDown(p.b, p.bo, p.t)) return false;

  jogF = 0; jogS = 0;
  Serial.println(F(">> Move the robot (wheels) and the arm until the 20 mm NOZZLE sits"));
  Serial.println(F(">> EXACTLY on the patient. Test with v (suction). Then y."));
  int r = jogLoop(true);
  if (r < 0) return false;
  setSuction(false);

  if (r == 1) {
    SlotData &sd = st.slot[s];
    sd.dx = (sd.ok ? sd.dx : 0) + jogF;
    sd.dy = (sd.ok ? sd.dy : 0) + jogS;
    sd.pick = {(int)armBase, (int)armBottom, (int)armTop};
    sd.ok = 1;

    // remember where the camera sees it (for the fine correction + the pick check)
    Serial.println(F("Recording the camera picture - do NOT touch the patient..."));
    if (!armOver(sd.pick.b, sd.pick.bo, sd.pick.t)) return false;
    if (!armLiftHere()) return false;
    waitMs(600);
    setAim(IMAGE_CENTER_X, IMAGE_CENTER_Y);
    int x0, y0, w0, h0;
    if (lookPrecise(x0, y0, w0, h0, SCAN_TIMEOUT_MS)) {
      sd.px = x0; sd.py = y0; sd.hasPix = 1;
      // camera calibration 1: turn the base a little
      if (armMoveTo(sd.pick.b + CAL_BASE_UNITS, st.scan.bo, st.scan.t, 400) && waitMs(500)) {
        int x1, y1, w1, h1;
        setAim(x0, y0);
        if (lookPrecise(x1, y1, w1, h1, SCAN_TIMEOUT_MS)) {
          float bx = (float)(x1 - x0) / CAL_BASE_UNITS, by = (float)(y1 - y0) / CAL_BASE_UNITS;
          if (fabs(bx) + fabs(by) > 0.2) { st.bx = bx; st.by = by; st.baseCal = 1; }
        }
      }
      if (!armScanAt(sd.pick.b)) return false;

      // camera calibration 2: strafe the robot a little LEFT and back
      st.strafeCal[s] = 0;
#if FINE_WHEELS
      Serial.println(F("Wheel calibration: robot strafes a little and comes back..."));
      int xa, ya, wa, ha;
      waitMs(SETTLE_MS);
      setAim(x0, y0);
      if (lookPrecise(xa, ya, wa, ha, SCAN_TIMEOUT_MS)) {
        if (!smallMove(STRAFE_LEFT, CAL_STRAFE_MM) || !fixHeading()) return false;
        waitMs(SETTLE_MS);
        int x2, y2, w2, h2;
        setAim(xa, ya);
        bool seen = lookPrecise(x2, y2, w2, h2, SCAN_TIMEOUT_MS);
        if (!smallMove(STRAFE_RIGHT, CAL_STRAFE_MM) || !fixHeading()) return false;
        if (seen) {
          float sx = (float)(x2 - xa) / CAL_STRAFE_MM, sy = (float)(y2 - ya) / CAL_STRAFE_MM;
          if (fabs(sx) + fabs(sy) > 0.2) {
            st.sx[s] = sx; st.sy[s] = sy; st.strafeCal[s] = 1;
            Serial.print(F("   wheel cal: "));
            Serial.print(sqrt(sx * sx + sy * sy), 2);
            Serial.println(F(" px per mm"));
          }
        }
      }
      if (!st.strafeCal[s]) Serial.println(F("   wheel cal FAILED - only the arm base will correct"));
#endif
    } else {
      sd.hasPix = 0;
      Serial.println(F("(camera did not see it from the scan height - pick works, but no fine correction)"));
    }
    storeSave();
    Serial.print(F("SLOT "));
    Serial.print(s + 1);
    Serial.println(F(" SAVED."));
  }

  if (!armToInitial()) return false;
  return navReturnNode();
}

// ---------------- TEACH ONE DROP ZONE ----------------
bool teachZone(Zone z) {
  Serial.println();
  Serial.print(F("=== TEACH ZONE "));
  Serial.print(zoneName(z));
  Serial.println(F(" ==="));
  if (!teachStart()) return false;
  if (!armToInitial()) return false;
  if (!navToZone(z, 0)) return false;

  Pose3 p = st.zone[z].place;
  // Recovery is BEHIND the robot: start with the RIGHT arm (reaching down), not the front one
  if (z == ZONE_RECOVERY && !st.zone[z].ok) p = {st.scan.b, PICK_BOTTOM, PICK_TOP};
  if (!armOver(p.b, p.bo, p.t)) return false;
  if (!armDown(p.b, p.bo, p.t)) return false;

  jogF = 0; jogS = 0;
  Serial.println(F(">> Move robot + arm so the patient will be DROPPED right inside the zone. Then y."));
  int r = jogLoop(true);
  if (r < 0) return false;
  if (r == 1) {
    ZoneData &zd = st.zone[z];
    zd.dx = (zd.ok ? zd.dx : 0) + jogF;
    zd.dy = (zd.ok ? zd.dy : 0) + jogS;
    zd.place = {(int)armBase, (int)armBottom, (int)armTop};
    zd.ok = 1;
    storeSave();
    Serial.print(zoneName(z));
    Serial.println(F(" SAVED."));
  }
  if (!armToInitial()) return false;
  return navReturnNode();
}

// ---------------- TEACH AN ARM POSE (no driving) ----------------
// which: 0 idle, 1 initial, 2 scan right, 3 scan left (base only)
bool teachPose(byte which) {
  Pose3 p;
  if (which == 0) p = st.idle;
  else if (which == 1) p = st.init;
  else if (which == 2) p = st.scan;
  else p = {st.scanLeftBase, st.scan.bo, st.scan.t};

  if (!armToPose(p, 1500)) return false;
  Serial.println(F(">> Move the arm with the keys, then y."));
  int r = jogLoop(false);
  if (r < 0) return false;
  if (r == 1) {
    Pose3 n = {(int)armBase, (int)armBottom, (int)armTop};
    if (which == 0) st.idle = n;
    else if (which == 1) st.init = n;
    else if (which == 2) st.scan = n;
    else st.scanLeftBase = n.b;
    storeSave();
    Serial.println(F("POSE SAVED."));
  }
  return true;
}
